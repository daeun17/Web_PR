# git page생성

강의: 독학
유형: git
자료: https://bamdule.tistory.com/183, https://wepplication.github.io/programming/github-pages/
작성일시: 2021년 8월 4일 오후 12:18

# git page 생성하기

git 레파지토리 생성 → git setting → page → none 을 master로 바꿔 주기 → save ⇒ git page 생성
* git file not found ⇒ index.html이 기본파일이다 이 파일이 아니라 다른 것을 열고 싶으면 주소 뒤에 파일 이름 적어서 접속하기
* git branch를 master branch로 설정해야 git page가 정상적으로 동작한다.
   → 파일을 올릴 때 git